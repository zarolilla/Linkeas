import { NavLink } from 'react-router-dom';
import { useToken } from '../../context/Authcontext';

import './Header.css';


import logo from '../../assets/logos/logo.png'


const Header =() => {
    const {token,setTokenInLocal,user} = useToken();

    
    
    

    return (
        <header className={token &&'headerlogo'}>
            
            {!token&&(<h1 className='biglogo'><NavLink to='/'  ><img className='biglogo' src={logo} alt="logo" /> </NavLink> </h1>
             )}
                
             {token&&(<h1 className='logos'><NavLink to='/'  ><img className='logo' src={logo} alt="logo" /> </NavLink> </h1>
             )}
             {token&&(
                <div className='user'>

                <div className='avatar'><NavLink to='/user'  > <img className='usuario' src={"src/assets/Profile-Avatar-PNG.png"} alt="avatar" /></NavLink>
                    </div>
                    
                {user && <p className='name'>@{user.name}</p> }
                    <nav> 
                        <input type="checkbox" id='check' />
                        <label htmlFor="check" className='checkbtn'>
                        <span className="hamburger-icon"><i className="fas fa-bars"></i></span>
                        </label>
                        <ul className='menu'>
                        <li className='buttons-post'>
                           <NavLink className={'new-post-buttons'} to ='/newpost'>Nuevo</NavLink>
                       </li>

                        <li className='buttons-post'>
                           <NavLink className={'new-post-buttons'} to ='/edite'>editar</NavLink>
                        </li>
                        <li className='buttons-post'>
                           <NavLink className={'new-post-buttons'} to ='/'>volver</NavLink>
                        </li>

                        <li className='buttons-post off' onClick={()=> setTokenInLocal(null) }>salir</li>
                        </ul>
                   
                    </nav>
                </div>
             )
             }   
                
               
                
               
                
        </header>

    );
}

export default Header;