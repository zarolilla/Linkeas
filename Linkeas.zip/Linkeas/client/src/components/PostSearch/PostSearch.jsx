import { useEffect } from 'react';
import { useState } from 'react';
import Post from '../Post/Post';
import './PostSearch.css';
import { getPosts } from '../../services/posts';
import { likePosts } from '../../services/likePosts';
import {useToken} from '../../context/Authcontext';
import { NavLink } from 'react-router-dom';
import { getPostSearch } from '../../services/getPostSearch';



const PostSearch =() => {
    const {token} = useToken();
    const [posts,setPosts] = useState();
    const [title,setTitle] = useState('');
    const [loading,setLoading] = useState(false);
    const [currentDate,setCurrentDate] = useState(new Date());
    const [searched,setSearched] = useState(false);
    

    

    useEffect(()=> {
        const fetchdata = async () => {
            setLoading(true);

            const posts = await getPosts(token,title,currentDate);
            
            if(posts) setPosts(posts);

            setLoading(false);
        };
        fetchdata();
    },[token,currentDate]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        const posts = await getPostSearch(token,title);
        setPosts(posts);
        setTitle('');
        setLoading(false);
        setSearched(true);
    } ;


     const handleCurrentDate = () => {
     setCurrentDate(new Date());
     setSearched(false);
    };

    
    
     
    

   return (
    <main className='post-search'>
        {token && (
            <form onSubmit={handleSubmit}>
                <input className='search' placeholder=" &#x1F50D; ...." type="text" value={title} onChange={(e)=> setTitle(e.target.value)} />
                <button disabled={loading}>buscar</button>
             </form>
        )}

        {token ? (<>
            <ul className='post-list'>
                {posts?.map((post) => (
                    <Post key={post.id} post={post} posts={posts} setPosts={setPosts} />
                    
                    ))}
                    
            </ul>
            {searched && (
                        <button className='atras' onClick={handleCurrentDate}>atras</button>
                        
                    )}
                    
            <div>
            <button className='previous' onClick={() => setCurrentDate(prevDate => new Date(prevDate.getTime() - 24 * 60 * 60 * 1000))}>
             Post Anteriores
            </button>
            {currentDate.toDateString() !== new Date().toDateString()&&(

                <button className='previous' onClick={handleCurrentDate}>Volver</button>
            )}
            </div>
            
                    </>
            
        ) : (
            <>
                <div className='bienvenida'>
                    <p className='start'>Bienvenido a LINKEAS!!!</p>
                    <NavLink className='empezar' to='/login'>entrar</NavLink>
                </div>
                
            </>
        )}
    </main>
);
}

export default PostSearch;