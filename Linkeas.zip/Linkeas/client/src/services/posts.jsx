export const getPosts = async (token,title,currentDate) => {
    try {
        let url = 'http://localhost:4000/posts';

        if (title) url += `?title=${title}`;

        const res = await fetch(url,{
            headers:{
                authorization:token,
            },
        });

        const body = await res.json();

        if(body.status === 'error'){
            alert(body.message);
            return false;

        } else {
      const filteredPosts = body.data.filter(
        (post) =>
          new Date(post.createdAt).toLocaleDateString() ===
          currentDate.toLocaleDateString()
      );
      return filteredPosts;
    }
  } catch (error) {
    console.error(error);
    return false;
  }
};