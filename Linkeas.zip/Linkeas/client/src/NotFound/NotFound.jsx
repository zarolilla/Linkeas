const NotFound =() => {
    return (
        <main className="not-found">
            <h2>pagina no encontrada</h2>
        </main>
    );
};

export default NotFound;