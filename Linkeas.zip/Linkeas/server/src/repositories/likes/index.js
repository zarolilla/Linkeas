const insertLike = require('./insertLike');
const deleteLike = require('./deleteLike');
const selectLikeByPostAndUser = require('./selectLikeByPostAndUser');

module.exports = { insertLike, deleteLike, selectLikeByPostAndUser };
