const getPool = require('../../database/getPool');

const updateUser = async (name, email, avatar, biografia, userId) => {
  const pool = getPool();

  await pool.query(
    `UPDATE users SET name = ?, email = ?, avatar = ?,biografia= ?, modifiedAt = ? WHERE id = ?`,
    [name, email, avatar, biografia, new Date(), userId]
  );
};

module.exports = updateUser;
