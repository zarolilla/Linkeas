const getPool = require('../../database/getPool');

const selectUserById = async (userId) => {
  const pool = getPool();

  const [users] = await pool.query(
    'SELECT id,name,email,avatar,biografia,createdAt FROM users WHERE id = ?',
    [userId]
  );

  return users[0];
};

module.exports = selectUserById;
