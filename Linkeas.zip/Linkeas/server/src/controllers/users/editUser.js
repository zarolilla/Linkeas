const selectUserById = require('../../repositories/users/selectUserById');
const updateUser = require('../../repositories/users/updateUser');

const { savePhoto, deletePhoto } = require('../../utils/saveAndDeletePhoto');

const editUser = async (req, res, next) => {
  try {
    let { name, email, biografia } = req.body;

    if (!name && !email) {
      throw generateError('Faltan campos', 400);
    }
    const user = await selectUserById(req.user.id);

    let avatar;

    if (req.files?.avatar) {
      if (user.avatar) {
        await deletePhoto(user.avatar);
      }
      avatar = await savePhoto(req.files.avatar);
    }

    name = name || user.name;
    email = email || user.email;
    avatar = avatar || user.avatar;
    biografia = biografia || user.biografia;

    console.log(user);

    await updateUser(name, email, avatar, biografia, req.user.id);

    res.send({
      status: 'ok',
      message: 'Usuario actualizado',
    });
  } catch (err) {
    next(err);
  }
};

module.exports = editUser;
