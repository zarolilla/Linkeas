const togglePostLike = require('./togglePostLike');

module.exports = { togglePostLike };
